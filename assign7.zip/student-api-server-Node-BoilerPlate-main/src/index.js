const express = require('express')
const app = express()
const bodyParser = require("body-parser");
const port = 8080
let studentArray = require("./InitialData")
app.use(express.urlencoded());

// Parse JSON bodies (as sent by API clients)
app.use(express.json());
app.use(bodyParser.urlencoded({ extended: false }))
app.use(bodyParser.json())
// your code goes here

app.get("/api/student",(req,res)=>{
    let InitData = studentArray;
    res.status(200).json({
        status: "success",
        result: InitData
    })
})

app.get("/api/student/:id",(req,res)=>{
    let stId = parseInt(req.params.id)
    let InitData = studentArray;
    if(stId){
        InitData  = studentArray.filter(data =>{
            if(data.id===stId){
                return data
            }
        })
    }
    res.set('Content-Type', 'application/x-www-form-urlencoded');
    res.status(200).json({
        message : "Success",
        result : InitData
    })
})

app.post("/api/student",(req,res)=>{
    let {name,currentClass,division} = req.body;
    if(name && currentClass && division){
        let newSt = {
            id : studentArray.length +1,
            name,
            currentClass,
            division
        }
        studentArray.push(newSt);
        res.set('Content-Type', 'application/x-www-form-urlencoded');
        res.status(200).json({studentArray})
    }else{
        res.status(400).json({
            message : "Please provide complete details"
        })
    }
})

app.put("/api/student/:id",(req,res)=>{
    const stId = req.params.id;
    const {name,currentClass,division} = req.body;
    const updatedId = studentArray.find((st)=>st.id ==stId);
    if(stId){
        if(name){
            updatedId.name = name;
            updatedId.currentClass = currentClass;
            updatedId.division = division;
            res.set('Content-Type', 'application/x-www-form-urlencoded');
            res.status(200).json({
                data : studentArray
            })
        }else{
            res.status(400).json({
                message : "Invalid data"
            })
        }
    }else{
        res.status(400).json({
            message:"Invalid Update"
        })
    }
})

app.delete("/api/student/:id",(req,res)=>{
    const deleteId = req.params.id;
    let deleteOne = studentArray.findIndex((stId)=>stId.id==deleteId);

    if(deleteOne){
        let result = studentArray.splice(deleteOne,1);
        res.status(200).json({
            message : "deleted successfully",
            data : result
        })
    }else{
        res.status(404).json({
            message : "not found"
        })
    }
})

app.listen(port, () => console.log(`App listening on port ${port}!`))

module.exports = app;   